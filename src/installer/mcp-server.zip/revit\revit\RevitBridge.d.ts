/**
 * RevitBridge - Communication bridge between Tycoon MCP Server and Revit Add-In
 *
 * Handles:
 * - WebSocket communication with Revit add-in
 * - Selection context management
 * - Element data serialization
 * - Real-time command execution
 * - Error handling and logging
 */
import { EventEmitter } from 'events';
export interface RevitElement {
    id: string;
    elementId: number;
    category: string;
    familyName?: string;
    typeName?: string;
    parameters: Record<string, any>;
    geometry?: {
        location?: {
            x: number;
            y: number;
            z: number;
        };
        boundingBox?: {
            min: {
                x: number;
                y: number;
                z: number;
            };
            max: {
                x: number;
                y: number;
                z: number;
            };
        };
    };
    relationships?: {
        hostId?: string;
        dependentIds?: string[];
    };
}
export interface RevitSelection {
    elements: RevitElement[];
    count: number;
    timestamp: string;
    viewId?: string;
    viewName?: string;
    documentTitle?: string;
}
export interface RevitCommand {
    id: string;
    type: 'selection' | 'create' | 'modify' | 'delete' | 'query';
    payload: any;
    timestamp: string;
}
export interface RevitResponse {
    commandId: string;
    success: boolean;
    data?: any;
    error?: string;
    timestamp: string;
}
export declare class RevitBridge extends EventEmitter {
    private wss;
    private revitConnection;
    private port;
    private isConnected;
    private pendingCommands;
    private commandTimeout;
    private debugMode;
    constructor(preferredPort?: number);
    /**
     * Find an available port starting from the preferred port
     */
    private findAvailablePort;
    /**
     * Check if a port is available
     */
    private isPortAvailable;
    /**
     * Initialize the WebSocket server for Revit communication
     */
    initialize(): Promise<void>;
    /**
     * Send command to Revit and wait for response
     */
    sendCommand(command: Omit<RevitCommand, 'id' | 'timestamp'>): Promise<RevitResponse>;
    /**
     * Get current Revit selection
     */
    getSelection(): Promise<RevitSelection>;
    /**
     * Handle incoming messages from Revit
     */
    private handleRevitMessage;
    /**
     * Send heartbeat response to keep connection alive
     */
    private sendHeartbeatResponse;
    /**
     * Generate unique command ID
     */
    private generateCommandId;
    /**
     * Check if connected to Revit
     */
    isRevitConnected(): boolean;
    /**
     * Get the current port being used
     */
    getPort(): number;
    /**
     * Close the bridge
     */
    close(): Promise<void>;
    /**
     * Enable/disable debug logging
     */
    setDebugMode(enabled: boolean): void;
    /**
     * Log debug messages
     */
    private log;
    /**
     * Log error messages
     */
    private logError;
}
//# sourceMappingURL=RevitBridge.d.ts.map
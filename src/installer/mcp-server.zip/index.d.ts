#!/usr/bin/env node
/**
 * Tycoon AI-BIM MCP Server
 *
 * Revolutionary AI-powered construction automation platform
 * Built on Temporal Neural Nexus foundation with live Revit integration
 *
 * Features:
 * - Real-time AI-Revit communication
 * - FLC steel framing workflows
 * - Live selection context
 * - Script generation with immediate feedback
 * - Advanced memory and learning system
 *
 * Created by: F.L. Crane & Sons Development Team
 * Version: 1.0.0
 */
export {};
//# sourceMappingURL=index.d.ts.map
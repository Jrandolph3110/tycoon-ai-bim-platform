/**
 * Analytics and Insights Models
 * Comprehensive analytics for memory usage and patterns
 */
export interface MemoryAnalytics {
    overview: MemoryOverview;
    usage: UsageStatistics;
    patterns: MemoryPatterns;
    health: MemoryHealth;
    insights: MemoryInsights;
    trends: MemoryTrends;
    generated: Date;
    timeRange: {
        start: Date;
        end: Date;
    };
}
export interface MemoryOverview {
    totalMemories: number;
    totalSize: number;
    averageSize: number;
    categories: CategoryStats[];
    tags: TagStats[];
    contexts: ContextStats[];
    importanceDistribution: ImportanceDistribution;
    creationRate: {
        daily: number;
        weekly: number;
        monthly: number;
    };
}
export interface CategoryStats {
    name: string;
    count: number;
    percentage: number;
    averageImportance: number;
    lastActivity: Date;
    growth: number;
}
export interface TagStats {
    name: string;
    count: number;
    coOccurrences: {
        [tag: string]: number;
    };
    averageImportance: number;
    trending: boolean;
    growth: number;
}
export interface ContextStats {
    name: string;
    memoryCount: number;
    isActive: boolean;
    lastUsed: Date;
    averageImportance: number;
    topTags: string[];
    topCategories: string[];
}
export interface ImportanceDistribution {
    distribution: {
        [importance: number]: number;
    };
    average: number;
    median: number;
    mode: number;
    standardDeviation: number;
}
export interface UsageStatistics {
    accessPatterns: AccessPattern[];
    searchQueries: SearchQueryStats[];
    mostAccessed: MemoryAccessStats[];
    leastAccessed: MemoryAccessStats[];
    peakUsageTimes: PeakUsageTime[];
    userBehavior: UserBehaviorStats;
}
export interface AccessPattern {
    memoryId: string;
    title: string;
    accessCount: number;
    lastAccessed: Date;
    accessFrequency: number;
    accessTrend: 'increasing' | 'decreasing' | 'stable';
}
export interface SearchQueryStats {
    query: string;
    count: number;
    successRate: number;
    averageResults: number;
    lastUsed: Date;
    relatedQueries: string[];
}
export interface MemoryAccessStats {
    memoryId: string;
    title: string;
    category: string;
    accessCount: number;
    lastAccessed: Date;
    importance: number;
    tags: string[];
}
export interface PeakUsageTime {
    hour: number;
    dayOfWeek: string;
    activityCount: number;
    activityTypes: {
        [type: string]: number;
    };
}
export interface UserBehaviorStats {
    averageSessionLength: number;
    preferredCategories: string[];
    preferredTags: string[];
    searchVsCreate: {
        searches: number;
        creates: number;
        ratio: number;
    };
    bulkOperations: number;
    exportOperations: number;
}
export interface MemoryPatterns {
    temporalPatterns: TemporalMemoryPattern[];
    contentPatterns: ContentPattern[];
    relationshipPatterns: RelationshipPattern[];
    clusterPatterns: ClusterPattern[];
}
export interface TemporalMemoryPattern {
    pattern: string;
    description: string;
    frequency: number;
    confidence: number;
    examples: Date[];
    relatedMemories: string[];
    seasonality?: {
        type: 'daily' | 'weekly' | 'monthly' | 'yearly';
        peak: string;
        low: string;
    };
}
export interface ContentPattern {
    pattern: string;
    type: 'keyword' | 'phrase' | 'structure' | 'length';
    frequency: number;
    examples: string[];
    relatedMemories: string[];
    significance: number;
}
export interface RelationshipPattern {
    type: string;
    frequency: number;
    strength: number;
    examples: Array<{
        fromId: string;
        toId: string;
        description: string;
    }>;
}
export interface ClusterPattern {
    clusterId: string;
    name: string;
    size: number;
    cohesion: number;
    commonThemes: string[];
    growthRate: number;
}
export interface MemoryHealth {
    score: number;
    issues: HealthIssue[];
    recommendations: HealthRecommendation[];
    duplicates: DuplicateMemory[];
    orphans: OrphanMemory[];
    staleness: StalenessInfo;
}
export interface HealthIssue {
    type: 'duplicate' | 'orphan' | 'stale' | 'untagged' | 'uncategorized' | 'low_importance';
    severity: 'low' | 'medium' | 'high';
    description: string;
    affectedMemories: string[];
    autoFixable: boolean;
}
export interface HealthRecommendation {
    type: 'cleanup' | 'organization' | 'tagging' | 'categorization' | 'archival';
    priority: 'low' | 'medium' | 'high';
    description: string;
    actionable: boolean;
    estimatedImpact: string;
}
export interface DuplicateMemory {
    memories: string[];
    similarity: number;
    type: 'exact' | 'near_exact' | 'semantic';
    recommendation: 'merge' | 'keep_separate' | 'review';
}
export interface OrphanMemory {
    memoryId: string;
    title: string;
    reason: 'no_relationships' | 'no_tags' | 'no_category' | 'never_accessed';
    lastActivity: Date;
}
export interface StalenessInfo {
    staleMemories: string[];
    threshold: number;
    averageStaleness: number;
    recommendations: string[];
}
export interface MemoryInsights {
    keyInsights: KeyInsight[];
    correlations: MemoryCorrelation[];
    predictions: MemoryPrediction[];
    anomalies: MemoryAnomaly[];
}
export interface KeyInsight {
    type: 'trend' | 'pattern' | 'correlation' | 'anomaly';
    title: string;
    description: string;
    confidence: number;
    impact: 'low' | 'medium' | 'high';
    actionable: boolean;
    relatedMemories: string[];
}
export interface MemoryCorrelation {
    type: 'tag_category' | 'time_content' | 'importance_access' | 'context_pattern';
    description: string;
    strength: number;
    significance: number;
    examples: string[];
}
export interface MemoryPrediction {
    type: 'access_pattern' | 'creation_trend' | 'category_growth' | 'tag_popularity';
    description: string;
    confidence: number;
    timeframe: string;
    expectedValue: number;
    factors: string[];
}
export interface MemoryAnomaly {
    type: 'unusual_access' | 'content_outlier' | 'timing_anomaly' | 'relationship_anomaly';
    description: string;
    severity: number;
    memoryIds: string[];
    detectedAt: Date;
    possibleCauses: string[];
}
export interface MemoryTrends {
    creationTrends: TrendData[];
    accessTrends: TrendData[];
    categoryTrends: TrendData[];
    tagTrends: TrendData[];
    importanceTrends: TrendData[];
}
export interface TrendData {
    period: string;
    value: number;
    change: number;
    trend: 'up' | 'down' | 'stable';
    forecast?: number;
}
//# sourceMappingURL=Analytics.d.ts.map
/**
 * Analytics Engine
 * Comprehensive analytics and insights for memory usage
 */
import { MemoryMetadata } from '../models/Memory.js';
import { MemoryAnalytics, MemoryOverview, UsageStatistics, MemoryPatterns, MemoryHealth, MemoryInsights, MemoryTrends } from '../models/Analytics.js';
export interface AnalyticsOptions {
    timeRange?: {
        start: Date;
        end: Date;
    };
    includePatterns?: boolean;
    includeHealth?: boolean;
    includeInsights?: boolean;
    includeTrends?: boolean;
}
export declare class AnalyticsEngine {
    private memories;
    private searchQueries;
    private accessLogs;
    /**
     * Initialize analytics engine with memories
     */
    initialize(memories: MemoryMetadata[]): void;
    /**
     * Log search query for analytics
     */
    logSearchQuery(query: string, resultCount: number): void;
    /**
     * Log memory access for analytics
     */
    logMemoryAccess(memoryId: string, action: string): void;
    /**
     * Generate comprehensive analytics report
     */
    generateAnalytics(options?: AnalyticsOptions): MemoryAnalytics;
    /**
     * Generate memory overview statistics
     */
    generateOverview(memories?: MemoryMetadata[]): MemoryOverview;
    /**
     * Generate usage statistics
     */
    generateUsageStatistics(memories: MemoryMetadata[], timeRange: {
        start: Date;
        end: Date;
    }): UsageStatistics;
    /**
     * Generate memory patterns analysis
     */
    generatePatterns(memories: MemoryMetadata[]): MemoryPatterns;
    /**
     * Generate health report
     */
    generateHealthReport(memories: MemoryMetadata[]): MemoryHealth;
    /**
     * Generate insights and correlations
     */
    generateInsights(memories: MemoryMetadata[]): MemoryInsights;
    /**
     * Generate trend analysis
     */
    generateTrends(memories: MemoryMetadata[], timeRange: {
        start: Date;
        end: Date;
    }): MemoryTrends;
    private filterMemoriesByTimeRange;
    private generateCategoryStats;
    private generateTagStats;
    private generateContextStats;
    private generateImportanceDistribution;
    private generateAccessPatterns;
    private generateSearchQueryStats;
    private getMostAccessedMemories;
    private getLeastAccessedMemories;
    private generatePeakUsageTimes;
    private generateUserBehaviorStats;
    private generateTemporalPatterns;
    private generateContentPatterns;
    private generateRelationshipPatterns;
    private generateClusterPatterns;
    private getEmptyPatterns;
    private getEmptyHealth;
    private getEmptyInsights;
    private getEmptyTrends;
    private identifyHealthIssues;
    private generateHealthRecommendations;
    private findDuplicateMemories;
    private findOrphanMemories;
    private analyzeStaleness;
    private generateKeyInsights;
    private generateCorrelations;
    private generatePredictions;
    private detectAnomalies;
    private generateCreationTrends;
    private generateAccessTrends;
    private generateCategoryTrends;
    private generateTagTrends;
    private generateImportanceTrends;
}
//# sourceMappingURL=AnalyticsEngine.d.ts.map
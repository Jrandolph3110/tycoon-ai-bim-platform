/**
 * Analytics Engine
 * Comprehensive analytics and insights for memory usage
 */
import { TextUtils } from '../utils/TextUtils.js';
export class AnalyticsEngine {
    memories = [];
    searchQueries = [];
    accessLogs = [];
    /**
     * Initialize analytics engine with memories
     */
    initialize(memories) {
        this.memories = memories;
    }
    /**
     * Log search query for analytics
     */
    logSearchQuery(query, resultCount) {
        this.searchQueries.push({
            query,
            timestamp: new Date(),
            resultCount
        });
        // Keep only last 1000 queries
        if (this.searchQueries.length > 1000) {
            this.searchQueries = this.searchQueries.slice(-1000);
        }
    }
    /**
     * Log memory access for analytics
     */
    logMemoryAccess(memoryId, action) {
        this.accessLogs.push({
            memoryId,
            timestamp: new Date(),
            action
        });
        // Keep only last 10000 access logs
        if (this.accessLogs.length > 10000) {
            this.accessLogs = this.accessLogs.slice(-10000);
        }
    }
    /**
     * Generate comprehensive analytics report
     */
    generateAnalytics(options = {}) {
        const timeRange = options.timeRange || {
            start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
            end: new Date()
        };
        const filteredMemories = this.filterMemoriesByTimeRange(this.memories, timeRange);
        return {
            overview: this.generateOverview(filteredMemories),
            usage: this.generateUsageStatistics(filteredMemories, timeRange),
            patterns: options.includePatterns !== false ? this.generatePatterns(filteredMemories) : this.getEmptyPatterns(),
            health: options.includeHealth !== false ? this.generateHealthReport(filteredMemories) : this.getEmptyHealth(),
            insights: options.includeInsights !== false ? this.generateInsights(filteredMemories) : this.getEmptyInsights(),
            trends: options.includeTrends !== false ? this.generateTrends(filteredMemories, timeRange) : this.getEmptyTrends(),
            generated: new Date(),
            timeRange
        };
    }
    /**
     * Generate memory overview statistics
     */
    generateOverview(memories = this.memories) {
        const totalSize = memories.reduce((sum, memory) => sum + (memory.content?.length || 0) + (memory.title?.length || 0), 0);
        const categories = this.generateCategoryStats(memories);
        const tags = this.generateTagStats(memories);
        const contexts = this.generateContextStats(memories);
        const importanceDistribution = this.generateImportanceDistribution(memories);
        // Calculate creation rates
        const now = new Date();
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const dailyCreated = memories.filter(m => new Date(m.created) >= oneDayAgo).length;
        const weeklyCreated = memories.filter(m => new Date(m.created) >= oneWeekAgo).length;
        const monthlyCreated = memories.filter(m => new Date(m.created) >= oneMonthAgo).length;
        return {
            totalMemories: memories.length,
            totalSize,
            averageSize: memories.length > 0 ? totalSize / memories.length : 0,
            categories,
            tags,
            contexts,
            importanceDistribution,
            creationRate: {
                daily: dailyCreated,
                weekly: weeklyCreated,
                monthly: monthlyCreated
            }
        };
    }
    /**
     * Generate usage statistics
     */
    generateUsageStatistics(memories, timeRange) {
        const accessPatterns = this.generateAccessPatterns(memories);
        const searchQueryStats = this.generateSearchQueryStats(timeRange);
        const mostAccessed = this.getMostAccessedMemories(memories, 10);
        const leastAccessed = this.getLeastAccessedMemories(memories, 10);
        const peakUsageTimes = this.generatePeakUsageTimes(timeRange);
        const userBehavior = this.generateUserBehaviorStats(timeRange);
        return {
            accessPatterns,
            searchQueries: searchQueryStats,
            mostAccessed,
            leastAccessed,
            peakUsageTimes,
            userBehavior
        };
    }
    /**
     * Generate memory patterns analysis
     */
    generatePatterns(memories) {
        return {
            temporalPatterns: this.generateTemporalPatterns(memories),
            contentPatterns: this.generateContentPatterns(memories),
            relationshipPatterns: this.generateRelationshipPatterns(memories),
            clusterPatterns: this.generateClusterPatterns(memories)
        };
    }
    /**
     * Generate health report
     */
    generateHealthReport(memories) {
        const issues = this.identifyHealthIssues(memories);
        const recommendations = this.generateHealthRecommendations(issues);
        const duplicates = this.findDuplicateMemories(memories);
        const orphans = this.findOrphanMemories(memories);
        const staleness = this.analyzeStaleness(memories);
        // Calculate overall health score
        const maxIssues = memories.length * 0.1; // 10% issues is considered poor health
        const issueWeight = Math.min(issues.length / maxIssues, 1);
        const score = Math.max(0, 100 - (issueWeight * 100));
        return {
            score,
            issues,
            recommendations,
            duplicates,
            orphans,
            staleness
        };
    }
    /**
     * Generate insights and correlations
     */
    generateInsights(memories) {
        return {
            keyInsights: this.generateKeyInsights(memories),
            correlations: this.generateCorrelations(memories),
            predictions: this.generatePredictions(memories),
            anomalies: this.detectAnomalies(memories)
        };
    }
    /**
     * Generate trend analysis
     */
    generateTrends(memories, timeRange) {
        return {
            creationTrends: this.generateCreationTrends(memories, timeRange),
            accessTrends: this.generateAccessTrends(timeRange),
            categoryTrends: this.generateCategoryTrends(memories, timeRange),
            tagTrends: this.generateTagTrends(memories, timeRange),
            importanceTrends: this.generateImportanceTrends(memories, timeRange)
        };
    }
    // Private helper methods
    filterMemoriesByTimeRange(memories, timeRange) {
        return memories.filter(memory => {
            const created = new Date(memory.created);
            return created >= timeRange.start && created <= timeRange.end;
        });
    }
    generateCategoryStats(memories) {
        const categoryMap = new Map();
        memories.forEach(memory => {
            const category = memory.category || 'Uncategorized';
            if (!categoryMap.has(category)) {
                categoryMap.set(category, []);
            }
            categoryMap.get(category).push(memory);
        });
        return Array.from(categoryMap.entries()).map(([name, categoryMemories]) => {
            const count = categoryMemories.length;
            const percentage = (count / memories.length) * 100;
            const averageImportance = categoryMemories.reduce((sum, m) => sum + m.importance, 0) / count;
            const lastActivity = new Date(Math.max(...categoryMemories.map(m => new Date(m.modified || m.created).getTime())));
            // Calculate growth (simplified - would need historical data for accurate calculation)
            const recentMemories = categoryMemories.filter(m => new Date(m.created).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000);
            const growth = (recentMemories.length / count) * 100;
            return {
                name,
                count,
                percentage,
                averageImportance,
                lastActivity,
                growth
            };
        }).sort((a, b) => b.count - a.count);
    }
    generateTagStats(memories) {
        const tagMap = new Map();
        memories.forEach(memory => {
            memory.tags.forEach(tag => {
                if (!tagMap.has(tag)) {
                    tagMap.set(tag, { memories: [], coOccurrences: new Map() });
                }
                tagMap.get(tag).memories.push(memory);
                // Track co-occurrences
                memory.tags.forEach(otherTag => {
                    if (otherTag !== tag) {
                        const coOccurrences = tagMap.get(tag).coOccurrences;
                        coOccurrences.set(otherTag, (coOccurrences.get(otherTag) || 0) + 1);
                    }
                });
            });
        });
        return Array.from(tagMap.entries()).map(([name, data]) => {
            const count = data.memories.length;
            const averageImportance = data.memories.reduce((sum, m) => sum + m.importance, 0) / count;
            // Calculate growth trend
            const recentMemories = data.memories.filter(m => new Date(m.created).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000);
            const growth = (recentMemories.length / count) * 100;
            const trending = growth > 20; // Arbitrary threshold
            const coOccurrences = {};
            data.coOccurrences.forEach((count, tag) => {
                coOccurrences[tag] = count;
            });
            return {
                name,
                count,
                coOccurrences,
                averageImportance,
                trending,
                growth
            };
        }).sort((a, b) => b.count - a.count);
    }
    generateContextStats(memories) {
        const contextMap = new Map();
        memories.forEach(memory => {
            const context = memory.context || 'Default';
            if (!contextMap.has(context)) {
                contextMap.set(context, []);
            }
            contextMap.get(context).push(memory);
        });
        return Array.from(contextMap.entries()).map(([name, contextMemories]) => {
            const memoryCount = contextMemories.length;
            const averageImportance = contextMemories.reduce((sum, m) => sum + m.importance, 0) / memoryCount;
            const lastUsed = new Date(Math.max(...contextMemories.map(m => new Date(m.lastAccessed).getTime())));
            const tagCounts = new Map();
            const categoryCounts = new Map();
            contextMemories.forEach(memory => {
                memory.tags.forEach(tag => {
                    tagCounts.set(tag, (tagCounts.get(tag) || 0) + 1);
                });
                categoryCounts.set(memory.category, (categoryCounts.get(memory.category) || 0) + 1);
            });
            const topTags = Array.from(tagCounts.entries())
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([tag, _]) => tag);
            const topCategories = Array.from(categoryCounts.entries())
                .sort((a, b) => b[1] - a[1])
                .slice(0, 3)
                .map(([category, _]) => category);
            return {
                name,
                memoryCount,
                isActive: name === 'Default',
                lastUsed,
                averageImportance,
                topTags,
                topCategories
            };
        }).sort((a, b) => b.memoryCount - a.memoryCount);
    }
    generateImportanceDistribution(memories) {
        const distribution = {};
        const importanceValues = [];
        memories.forEach(memory => {
            const importance = memory.importance;
            distribution[importance] = (distribution[importance] || 0) + 1;
            importanceValues.push(importance);
        });
        const average = importanceValues.reduce((sum, val) => sum + val, 0) / importanceValues.length;
        const sortedValues = importanceValues.sort((a, b) => a - b);
        const median = sortedValues[Math.floor(sortedValues.length / 2)];
        const mode = Object.entries(distribution)
            .reduce((a, b) => distribution[parseInt(a[0])] > distribution[parseInt(b[0])] ? a : b)[0];
        const variance = importanceValues.reduce((sum, val) => sum + Math.pow(val - average, 2), 0) / importanceValues.length;
        const standardDeviation = Math.sqrt(variance);
        return {
            distribution,
            average,
            median,
            mode: parseInt(mode),
            standardDeviation
        };
    }
    generateAccessPatterns(memories) {
        return memories.map(memory => {
            const daysSinceCreated = (Date.now() - new Date(memory.created).getTime()) / (1000 * 60 * 60 * 24);
            const accessFrequency = daysSinceCreated > 0 ? memory.accessCount / daysSinceCreated : 0;
            let accessTrend = 'stable';
            if (accessFrequency > 1)
                accessTrend = 'increasing';
            else if (accessFrequency < 0.1)
                accessTrend = 'decreasing';
            return {
                memoryId: memory.id,
                title: memory.title,
                accessCount: memory.accessCount,
                lastAccessed: new Date(memory.lastAccessed),
                accessFrequency,
                accessTrend
            };
        }).sort((a, b) => b.accessCount - a.accessCount);
    }
    generateSearchQueryStats(timeRange) {
        const queryMap = new Map();
        this.searchQueries
            .filter(q => q.timestamp >= timeRange.start && q.timestamp <= timeRange.end)
            .forEach(query => {
            const existing = queryMap.get(query.query);
            if (existing) {
                existing.count++;
                existing.results.push(query.resultCount);
                existing.lastUsed = new Date(Math.max(existing.lastUsed.getTime(), query.timestamp.getTime()));
            }
            else {
                queryMap.set(query.query, {
                    count: 1,
                    results: [query.resultCount],
                    lastUsed: query.timestamp
                });
            }
        });
        return Array.from(queryMap.entries()).map(([query, data]) => {
            const successRate = (data.results.filter(r => r > 0).length / data.results.length) * 100;
            const averageResults = data.results.reduce((sum, r) => sum + r, 0) / data.results.length;
            const relatedQueries = Array.from(queryMap.keys())
                .filter(q => q !== query && TextUtils.fuzzySimilarity(q, query) > 0.7)
                .slice(0, 3);
            return {
                query,
                count: data.count,
                successRate,
                averageResults,
                lastUsed: data.lastUsed,
                relatedQueries
            };
        }).sort((a, b) => b.count - a.count);
    }
    getMostAccessedMemories(memories, limit) {
        return memories
            .sort((a, b) => b.accessCount - a.accessCount)
            .slice(0, limit)
            .map(memory => ({
            memoryId: memory.id,
            title: memory.title,
            category: memory.category,
            accessCount: memory.accessCount,
            lastAccessed: new Date(memory.lastAccessed),
            importance: memory.importance,
            tags: memory.tags
        }));
    }
    getLeastAccessedMemories(memories, limit) {
        return memories
            .sort((a, b) => a.accessCount - b.accessCount)
            .slice(0, limit)
            .map(memory => ({
            memoryId: memory.id,
            title: memory.title,
            category: memory.category,
            accessCount: memory.accessCount,
            lastAccessed: new Date(memory.lastAccessed),
            importance: memory.importance,
            tags: memory.tags
        }));
    }
    // Simplified placeholder implementations
    generatePeakUsageTimes(timeRange) {
        return [];
    }
    generateUserBehaviorStats(timeRange) {
        return {
            averageSessionLength: 30,
            preferredCategories: [],
            preferredTags: [],
            searchVsCreate: { searches: 0, creates: 0, ratio: 0 },
            bulkOperations: 0,
            exportOperations: 0
        };
    }
    generateTemporalPatterns(memories) {
        return [];
    }
    generateContentPatterns(memories) {
        return [];
    }
    generateRelationshipPatterns(memories) {
        return [];
    }
    generateClusterPatterns(memories) {
        return [];
    }
    getEmptyPatterns() {
        return {
            temporalPatterns: [],
            contentPatterns: [],
            relationshipPatterns: [],
            clusterPatterns: []
        };
    }
    getEmptyHealth() {
        return {
            score: 100,
            issues: [],
            recommendations: [],
            duplicates: [],
            orphans: [],
            staleness: { staleMemories: [], threshold: 30, averageStaleness: 0, recommendations: [] }
        };
    }
    getEmptyInsights() {
        return {
            keyInsights: [],
            correlations: [],
            predictions: [],
            anomalies: []
        };
    }
    getEmptyTrends() {
        return {
            creationTrends: [],
            accessTrends: [],
            categoryTrends: [],
            tagTrends: [],
            importanceTrends: []
        };
    }
    identifyHealthIssues(memories) {
        return [];
    }
    generateHealthRecommendations(issues) {
        return [];
    }
    findDuplicateMemories(memories) {
        return [];
    }
    findOrphanMemories(memories) {
        return [];
    }
    analyzeStaleness(memories) {
        return {
            staleMemories: [],
            threshold: 30,
            averageStaleness: 0,
            recommendations: []
        };
    }
    generateKeyInsights(memories) {
        return [];
    }
    generateCorrelations(memories) {
        return [];
    }
    generatePredictions(memories) {
        return [];
    }
    detectAnomalies(memories) {
        return [];
    }
    generateCreationTrends(memories, timeRange) {
        return [];
    }
    generateAccessTrends(timeRange) {
        return [];
    }
    generateCategoryTrends(memories, timeRange) {
        return [];
    }
    generateTagTrends(memories, timeRange) {
        return [];
    }
    generateImportanceTrends(memories, timeRange) {
        return [];
    }
}
//# sourceMappingURL=AnalyticsEngine.js.map
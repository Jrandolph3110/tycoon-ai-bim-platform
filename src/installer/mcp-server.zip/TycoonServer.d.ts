/**
 * TycoonServer - Main MCP Server for Tycoon AI-BIM Platform
 *
 * Extends Temporal Neural Nexus with Revit-specific capabilities:
 * - Live Revit selection context
 * - Steel framing operations
 * - FLC workflow integration
 * - Real-time AI-Revit communication
 */
export declare class TycoonServer {
    private server;
    private memoryManager;
    private timeManager;
    private revitBridge;
    private flcAdapter;
    private isInitialized;
    constructor();
    /**
     * Initialize the Tycoon server
     */
    initialize(): Promise<void>;
    /**
     * Setup Revit event handlers
     */
    private setupRevitEventHandlers;
    /**
     * Handle Revit selection changes
     */
    private handleSelectionChange;
    /**
     * Setup error handling
     */
    private setupErrorHandling;
    /**
     * Shutdown the server gracefully
     */
    shutdown(): Promise<void>;
    /**
     * Setup tool handlers (extending Temporal Neural Nexus tools)
     */
    private setupToolHandlers;
    /**
     * Initialize Tycoon platform
     */
    private initializeTycoon;
    /**
     * Get current Revit selection
     */
    private getRevitSelection;
    /**
     * Analyze walls for framing
     */
    private analyzeWallsForFraming;
    /**
     * Create steel framing
     */
    private createSteelFraming;
    /**
     * Renumber elements
     */
    private renumberElements;
    /**
     * Validate panel tickets
     */
    private validatePanelTickets;
    /**
     * Get Revit status
     */
    private getRevitStatus;
    /**
     * Helper: Create memory (simplified interface)
     */
    private createMemory;
    /**
     * Start the server
     */
    start(): Promise<void>;
}
//# sourceMappingURL=TycoonServer.d.ts.map
/**
 * Text Processing Utilities
 * Advanced text analysis and processing functions
 */
import natural from 'natural';
const { PorterStemmer } = natural;
export class TextUtils {
    static STOP_WORDS = new Set([
        'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
        'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
        'to', 'was', 'will', 'with', 'would', 'could', 'should', 'can',
        'may', 'might', 'must', 'shall', 'this', 'these', 'those', 'they',
        'them', 'their', 'there', 'where', 'when', 'why', 'how', 'what',
        'who', 'which', 'i', 'you', 'we', 'us', 'me', 'my', 'your', 'our'
    ]);
    /**
     * Extract keywords from text using TF-IDF and frequency analysis
     */
    static extractKeywords(text, maxKeywords = 10) {
        const words = this.tokenize(text);
        const filteredWords = words.filter(word => word.length > 2 &&
            !this.STOP_WORDS.has(word.toLowerCase()) &&
            /^[a-zA-Z]+$/.test(word));
        const wordFreq = new Map();
        filteredWords.forEach(word => {
            const stemmed = PorterStemmer.stem(word.toLowerCase());
            wordFreq.set(stemmed, (wordFreq.get(stemmed) || 0) + 1);
        });
        return Array.from(wordFreq.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, maxKeywords)
            .map(([word, _]) => word);
    }
    /**
     * Tokenize text into words
     */
    static tokenize(text) {
        return text
            .toLowerCase()
            .replace(/[^\w\s]/g, ' ')
            .split(/\s+/)
            .filter(word => word.length > 0);
    }
    /**
     * Calculate text similarity using Jaccard index
     */
    static jaccardSimilarity(text1, text2) {
        const words1 = new Set(this.tokenize(text1));
        const words2 = new Set(this.tokenize(text2));
        const intersection = new Set([...words1].filter(x => words2.has(x)));
        const union = new Set([...words1, ...words2]);
        return union.size === 0 ? 0 : intersection.size / union.size;
    }
    /**
     * Calculate Levenshtein distance between two strings
     */
    static levenshteinDistance(str1, str2) {
        const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));
        for (let i = 0; i <= str1.length; i++)
            matrix[0][i] = i;
        for (let j = 0; j <= str2.length; j++)
            matrix[j][0] = j;
        for (let j = 1; j <= str2.length; j++) {
            for (let i = 1; i <= str1.length; i++) {
                const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
                matrix[j][i] = Math.min(matrix[j][i - 1] + 1, // deletion
                matrix[j - 1][i] + 1, // insertion
                matrix[j - 1][i - 1] + indicator // substitution
                );
            }
        }
        return matrix[str2.length][str1.length];
    }
    /**
     * Calculate fuzzy string similarity (0-1 scale)
     */
    static fuzzySimilarity(str1, str2) {
        const maxLength = Math.max(str1.length, str2.length);
        if (maxLength === 0)
            return 1;
        const distance = this.levenshteinDistance(str1, str2);
        return 1 - (distance / maxLength);
    }
    /**
     * Extract sentences from text
     */
    static extractSentences(text) {
        return text
            .split(/[.!?]+/)
            .map(sentence => sentence.trim())
            .filter(sentence => sentence.length > 0);
    }
    /**
     * Generate a summary of text (extractive summarization)
     */
    static generateSummary(text, maxSentences = 3) {
        const sentences = this.extractSentences(text);
        if (sentences.length <= maxSentences)
            return text;
        // Score sentences based on word frequency and position
        const wordFreq = new Map();
        const words = this.tokenize(text);
        words.forEach(word => {
            if (!this.STOP_WORDS.has(word)) {
                wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
            }
        });
        const sentenceScores = sentences.map((sentence, index) => {
            const sentenceWords = this.tokenize(sentence);
            const score = sentenceWords.reduce((sum, word) => {
                return sum + (wordFreq.get(word) || 0);
            }, 0) / sentenceWords.length;
            // Boost score for sentences at the beginning
            const positionBoost = index < sentences.length * 0.3 ? 1.2 : 1;
            return { sentence, score: score * positionBoost, index };
        });
        return sentenceScores
            .sort((a, b) => b.score - a.score)
            .slice(0, maxSentences)
            .sort((a, b) => a.index - b.index)
            .map(item => item.sentence)
            .join('. ') + '.';
    }
    /**
     * Extract key phrases from text
     */
    static extractKeyPhrases(text, maxPhrases = 5) {
        const sentences = this.extractSentences(text);
        const phrases = [];
        for (const sentence of sentences) {
            const words = this.tokenize(sentence);
            // Extract 2-3 word phrases
            for (let i = 0; i < words.length - 1; i++) {
                if (!this.STOP_WORDS.has(words[i]) && !this.STOP_WORDS.has(words[i + 1])) {
                    phrases.push(`${words[i]} ${words[i + 1]}`);
                    if (i < words.length - 2 && !this.STOP_WORDS.has(words[i + 2])) {
                        phrases.push(`${words[i]} ${words[i + 1]} ${words[i + 2]}`);
                    }
                }
            }
        }
        // Count phrase frequencies
        const phraseFreq = new Map();
        phrases.forEach(phrase => {
            phraseFreq.set(phrase, (phraseFreq.get(phrase) || 0) + 1);
        });
        return Array.from(phraseFreq.entries())
            .filter(([_, freq]) => freq > 1)
            .sort((a, b) => b[1] - a[1])
            .slice(0, maxPhrases)
            .map(([phrase, _]) => phrase);
    }
    /**
     * Detect the language of text (simple heuristic)
     */
    static detectLanguage(text) {
        const commonWords = {
            en: ['the', 'and', 'is', 'in', 'to', 'of', 'a', 'that', 'it', 'with'],
            es: ['el', 'la', 'de', 'que', 'y', 'a', 'en', 'un', 'es', 'se'],
            fr: ['le', 'de', 'et', 'à', 'un', 'il', 'être', 'et', 'en', 'avoir'],
            de: ['der', 'die', 'und', 'in', 'den', 'von', 'zu', 'das', 'mit', 'sich']
        };
        const words = this.tokenize(text.toLowerCase());
        const scores = {};
        for (const [lang, commonWordList] of Object.entries(commonWords)) {
            scores[lang] = words.filter(word => commonWordList.includes(word)).length;
        }
        const detectedLang = Object.entries(scores).reduce((a, b) => scores[a[0]] > scores[b[0]] ? a : b)[0];
        return detectedLang;
    }
    /**
     * Clean and normalize text
     */
    static cleanText(text) {
        return text
            .replace(/\s+/g, ' ') // Multiple spaces to single space
            .replace(/\n+/g, '\n') // Multiple newlines to single newline
            .replace(/[^\w\s\n.,!?;:-]/g, '') // Remove special characters except basic punctuation
            .trim();
    }
    /**
     * Calculate readability score (Flesch Reading Ease approximation)
     */
    static calculateReadability(text) {
        const sentences = this.extractSentences(text);
        const words = this.tokenize(text);
        const syllables = words.reduce((sum, word) => sum + this.countSyllables(word), 0);
        if (sentences.length === 0 || words.length === 0) {
            return { score: 0, level: 'Unknown', description: 'Insufficient text' };
        }
        const avgSentenceLength = words.length / sentences.length;
        const avgSyllablesPerWord = syllables / words.length;
        const score = 206.835 - (1.015 * avgSentenceLength) - (84.6 * avgSyllablesPerWord);
        let level;
        let description;
        if (score >= 90) {
            level = 'Very Easy';
            description = '5th grade level';
        }
        else if (score >= 80) {
            level = 'Easy';
            description = '6th grade level';
        }
        else if (score >= 70) {
            level = 'Fairly Easy';
            description = '7th grade level';
        }
        else if (score >= 60) {
            level = 'Standard';
            description = '8th-9th grade level';
        }
        else if (score >= 50) {
            level = 'Fairly Difficult';
            description = '10th-12th grade level';
        }
        else if (score >= 30) {
            level = 'Difficult';
            description = 'College level';
        }
        else {
            level = 'Very Difficult';
            description = 'Graduate level';
        }
        return { score: Math.max(0, Math.min(100, score)), level, description };
    }
    /**
     * Count syllables in a word (approximation)
     */
    static countSyllables(word) {
        word = word.toLowerCase();
        if (word.length <= 3)
            return 1;
        const vowels = 'aeiouy';
        let count = 0;
        let previousWasVowel = false;
        for (let i = 0; i < word.length; i++) {
            const isVowel = vowels.includes(word[i]);
            if (isVowel && !previousWasVowel) {
                count++;
            }
            previousWasVowel = isVowel;
        }
        // Handle silent 'e'
        if (word.endsWith('e')) {
            count--;
        }
        return Math.max(1, count);
    }
    /**
     * Generate auto-tags from text content
     */
    static generateAutoTags(text, maxTags = 5) {
        const keywords = this.extractKeywords(text, maxTags * 2);
        const phrases = this.extractKeyPhrases(text, maxTags);
        const allCandidates = [...keywords, ...phrases];
        const tagFreq = new Map();
        allCandidates.forEach(tag => {
            const normalized = tag.toLowerCase().replace(/\s+/g, '_');
            tagFreq.set(normalized, (tagFreq.get(normalized) || 0) + 1);
        });
        return Array.from(tagFreq.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, maxTags)
            .map(([tag, _]) => tag);
    }
}
//# sourceMappingURL=TextUtils.js.map
/**
 * RevitBridge - Communication bridge between Tycoon MCP Server and Revit Add-In
 *
 * Handles:
 * - WebSocket communication with Revit add-in
 * - Selection context management
 * - Element data serialization
 * - Real-time command execution
 * - Error handling and logging
 */
import { WebSocketServer } from 'ws';
import { EventEmitter } from 'events';
import { createServer } from 'net';
import chalk from 'chalk';
export class RevitBridge extends EventEmitter {
    wss = null;
    revitConnection = null;
    port;
    isConnected = false;
    pendingCommands = new Map();
    commandTimeout = 30000; // 30 seconds
    debugMode = true;
    constructor(preferredPort = 8765) {
        super();
        this.port = preferredPort;
    }
    /**
     * Find an available port starting from the preferred port
     */
    async findAvailablePort(startPort = 8765) {
        const maxAttempts = 100; // Try 100 ports
        for (let port = startPort; port < startPort + maxAttempts; port++) {
            if (await this.isPortAvailable(port)) {
                return port;
            }
        }
        throw new Error(`No available port found in range ${startPort}-${startPort + maxAttempts}`);
    }
    /**
     * Check if a port is available
     */
    async isPortAvailable(port) {
        return new Promise((resolve) => {
            const server = createServer();
            server.listen(port, () => {
                server.once('close', () => {
                    resolve(true);
                });
                server.close();
            });
            server.on('error', () => {
                resolve(false);
            });
        });
    }
    /**
     * Initialize the WebSocket server for Revit communication
     */
    async initialize() {
        try {
            // Find an available port
            this.port = await this.findAvailablePort(this.port);
            this.log(`🔍 Found available port: ${this.port}`);
            this.wss = new WebSocketServer({
                port: this.port,
                perMessageDeflate: false
            });
            this.wss.on('connection', (ws) => {
                this.log('🔗 Revit add-in connected');
                this.revitConnection = ws;
                this.isConnected = true;
                ws.on('message', (data) => {
                    try {
                        const message = JSON.parse(data.toString());
                        this.handleRevitMessage(message);
                    }
                    catch (error) {
                        this.logError('Failed to parse message from Revit', error);
                    }
                });
                ws.on('close', () => {
                    this.log('❌ Revit add-in disconnected');
                    this.isConnected = false;
                    this.revitConnection = null;
                    this.emit('disconnected');
                });
                ws.on('error', (error) => {
                    this.logError('WebSocket error', error);
                    this.emit('error', error);
                });
                this.emit('connected');
            });
            this.log(`🚀 Tycoon RevitBridge listening on port ${this.port}`);
        }
        catch (error) {
            this.logError('Failed to initialize RevitBridge', error);
            throw error;
        }
    }
    /**
     * Send command to Revit and wait for response
     */
    async sendCommand(command) {
        if (!this.isConnected || !this.revitConnection) {
            throw new Error('Revit add-in not connected');
        }
        const fullCommand = {
            ...command,
            id: this.generateCommandId(),
            timestamp: new Date().toISOString()
        };
        return new Promise((resolve, reject) => {
            // Set up timeout
            const timeout = setTimeout(() => {
                this.pendingCommands.delete(fullCommand.id);
                reject(new Error(`Command timeout: ${fullCommand.type}`));
            }, this.commandTimeout);
            // Store pending command
            this.pendingCommands.set(fullCommand.id, { resolve, reject, timeout });
            // Send command
            try {
                this.revitConnection.send(JSON.stringify(fullCommand));
                this.log(`📤 Sent command: ${fullCommand.type} (${fullCommand.id})`);
            }
            catch (error) {
                this.pendingCommands.delete(fullCommand.id);
                clearTimeout(timeout);
                reject(error);
            }
        });
    }
    /**
     * Get current Revit selection
     */
    async getSelection() {
        const response = await this.sendCommand({
            type: 'selection',
            payload: { action: 'get' }
        });
        if (!response.success) {
            throw new Error(`Failed to get selection: ${response.error}`);
        }
        return response.data;
    }
    /**
     * Handle incoming messages from Revit
     */
    handleRevitMessage(message) {
        this.log(`📥 Received from Revit: ${message.type || 'unknown'}`);
        if (message.commandId && this.pendingCommands.has(message.commandId)) {
            // Handle command response
            const pending = this.pendingCommands.get(message.commandId);
            this.pendingCommands.delete(message.commandId);
            clearTimeout(pending.timeout);
            if (message.success) {
                pending.resolve(message);
            }
            else {
                pending.reject(new Error(message.error || 'Unknown error'));
            }
        }
        else if (message.type === 'selection_changed') {
            // Handle selection change notification
            this.emit('selectionChanged', message.data);
        }
        else if (message.type === 'heartbeat') {
            // Handle heartbeat
            this.sendHeartbeatResponse();
        }
        else {
            this.log(`⚠️ Unhandled message type: ${message.type}`);
        }
    }
    /**
     * Send heartbeat response to keep connection alive
     */
    sendHeartbeatResponse() {
        if (this.revitConnection) {
            this.revitConnection.send(JSON.stringify({
                type: 'heartbeat_response',
                timestamp: new Date().toISOString()
            }));
        }
    }
    /**
     * Generate unique command ID
     */
    generateCommandId() {
        return `cmd_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    /**
     * Check if connected to Revit
     */
    isRevitConnected() {
        return this.isConnected;
    }
    /**
     * Get the current port being used
     */
    getPort() {
        return this.port;
    }
    /**
     * Close the bridge
     */
    async close() {
        if (this.revitConnection) {
            this.revitConnection.close();
        }
        if (this.wss) {
            this.wss.close();
        }
        this.log('🛑 RevitBridge closed');
    }
    /**
     * Enable/disable debug logging
     */
    setDebugMode(enabled) {
        this.debugMode = enabled;
    }
    /**
     * Log debug messages
     */
    log(message) {
        if (this.debugMode) {
            console.log(chalk.cyan('[RevitBridge]'), message);
        }
    }
    /**
     * Log error messages
     */
    logError(message, error) {
        console.error(chalk.red('[RevitBridge Error]'), message, error || '');
    }
}
//# sourceMappingURL=RevitBridge.js.map
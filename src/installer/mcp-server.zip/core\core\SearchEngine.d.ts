/**
 * Search Engine
 * Advanced search capabilities for memory retrieval
 */
import { MemoryMetadata, MemorySearchResult } from '../models/Memory.js';
export interface SearchOptions {
    maxResults?: number;
    threshold?: number;
    includeScore?: boolean;
    searchFields?: string[];
    fuzzyThreshold?: number;
    semanticThreshold?: number;
}
export interface SearchQuery {
    text?: string;
    tags?: string[];
    categories?: string[];
    contexts?: string[];
    dateRange?: {
        start: Date;
        end: Date;
    };
    importance?: {
        min?: number;
        max?: number;
    };
    searchType?: 'all' | 'exact' | 'fuzzy' | 'semantic' | 'tags' | 'categories';
}
export declare class SearchEngine {
    private fuseIndex;
    private vocabulary;
    private documentFrequencies;
    private memories;
    /**
     * Initialize search engine with memories
     */
    initialize(memories: MemoryMetadata[]): void;
    /**
     * Add memory to search index
     */
    addMemory(memory: MemoryMetadata): void;
    /**
     * Update memory in search index
     */
    updateMemory(memory: MemoryMetadata): void;
    /**
     * Remove memory from search index
     */
    removeMemory(memoryId: string): void;
    /**
     * Comprehensive search across all memory fields
     */
    search(query: SearchQuery, options?: SearchOptions): MemorySearchResult[];
    /**
     * Find similar memories using semantic search
     */
    findSimilar(memoryId: string, options?: SearchOptions): MemorySearchResult[];
    /**
     * Search by tags with fuzzy matching
     */
    searchByTags(tags: string[], options?: SearchOptions): MemorySearchResult[];
    /**
     * Search by categories
     */
    searchByCategories(categories: string[], options?: SearchOptions): MemorySearchResult[];
    /**
     * Search within date range
     */
    searchByDateRange(start: Date, end: Date, options?: SearchOptions): MemorySearchResult[];
    /**
     * Full-text search across all content
     */
    fullTextSearch(query: string, options?: SearchOptions): MemorySearchResult[];
    /**
     * Get search suggestions based on partial query
     */
    getSuggestions(partialQuery: string, maxSuggestions?: number): string[];
    /**
     * Get search statistics
     */
    getSearchStats(): {
        totalMemories: number;
        indexedMemories: number;
        vocabularySize: number;
        averageEmbeddingDimensions: number;
    };
    private buildFuseIndex;
    private buildVocabulary;
    private rebuildIndices;
    private applyFilters;
    private exactSearch;
    private fuzzySearch;
    private semanticSearch;
    private combinedSearch;
    private tagSearch;
    private categorySearch;
    private deduplicateResults;
}
//# sourceMappingURL=SearchEngine.d.ts.map
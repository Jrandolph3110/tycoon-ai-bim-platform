/**
 * Vector Utilities for Semantic Search
 * Simple vector operations for memory similarity
 */
import { createHash } from 'crypto';
export class VectorUtils {
    /**
     * Create a simple vector embedding from text using character frequency
     * This is a basic implementation - in production you'd use a proper embedding model
     */
    static createEmbedding(text, dimensions = 100) {
        const normalized = text.toLowerCase().replace(/[^\w\s]/g, ' ').trim();
        const words = normalized.split(/\s+/).filter(word => word.length > 2);
        // Create a hash-based vector
        const vector = new Array(dimensions).fill(0);
        for (const word of words) {
            const hash = createHash('md5').update(word).digest('hex');
            for (let i = 0; i < dimensions; i++) {
                const charCode = hash.charCodeAt(i % hash.length);
                vector[i] += Math.sin(charCode * (i + 1)) * 0.1;
            }
        }
        // Normalize the vector
        return this.normalizeVector(vector);
    }
    /**
     * Calculate cosine similarity between two vectors
     */
    static cosineSimilarity(vectorA, vectorB) {
        if (vectorA.length !== vectorB.length) {
            throw new Error('Vectors must have the same length');
        }
        let dotProduct = 0;
        let magnitudeA = 0;
        let magnitudeB = 0;
        for (let i = 0; i < vectorA.length; i++) {
            dotProduct += vectorA[i] * vectorB[i];
            magnitudeA += vectorA[i] * vectorA[i];
            magnitudeB += vectorB[i] * vectorB[i];
        }
        magnitudeA = Math.sqrt(magnitudeA);
        magnitudeB = Math.sqrt(magnitudeB);
        if (magnitudeA === 0 || magnitudeB === 0) {
            return 0;
        }
        return dotProduct / (magnitudeA * magnitudeB);
    }
    /**
     * Normalize a vector to unit length
     */
    static normalizeVector(vector) {
        const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
        if (magnitude === 0)
            return vector;
        return vector.map(val => val / magnitude);
    }
    /**
     * Calculate Euclidean distance between two vectors
     */
    static euclideanDistance(vectorA, vectorB) {
        if (vectorA.length !== vectorB.length) {
            throw new Error('Vectors must have the same length');
        }
        let sum = 0;
        for (let i = 0; i < vectorA.length; i++) {
            const diff = vectorA[i] - vectorB[i];
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }
    /**
     * Find the centroid of multiple vectors
     */
    static calculateCentroid(vectors) {
        if (vectors.length === 0)
            return [];
        const dimensions = vectors[0].length;
        const centroid = new Array(dimensions).fill(0);
        for (const vector of vectors) {
            for (let i = 0; i < dimensions; i++) {
                centroid[i] += vector[i];
            }
        }
        return centroid.map(val => val / vectors.length);
    }
    /**
     * Cluster vectors using simple k-means
     */
    static kMeansCluster(vectors, k, maxIterations = 100) {
        if (vectors.length === 0 || k <= 0) {
            return { clusters: [], centroids: [], assignments: [] };
        }
        const dimensions = vectors[0].length;
        // Initialize centroids randomly
        let centroids = [];
        for (let i = 0; i < k; i++) {
            const randomVector = vectors[Math.floor(Math.random() * vectors.length)];
            centroids.push([...randomVector]);
        }
        let assignments = new Array(vectors.length).fill(0);
        for (let iteration = 0; iteration < maxIterations; iteration++) {
            let changed = false;
            // Assign each vector to the nearest centroid
            for (let i = 0; i < vectors.length; i++) {
                let minDistance = Infinity;
                let bestCluster = 0;
                for (let j = 0; j < centroids.length; j++) {
                    const distance = this.euclideanDistance(vectors[i], centroids[j]);
                    if (distance < minDistance) {
                        minDistance = distance;
                        bestCluster = j;
                    }
                }
                if (assignments[i] !== bestCluster) {
                    assignments[i] = bestCluster;
                    changed = true;
                }
            }
            // Update centroids
            const newCentroids = [];
            for (let j = 0; j < k; j++) {
                const clusterVectors = vectors.filter((_, i) => assignments[i] === j);
                if (clusterVectors.length > 0) {
                    newCentroids.push(this.calculateCentroid(clusterVectors));
                }
                else {
                    newCentroids.push([...centroids[j]]);
                }
            }
            centroids = newCentroids;
            if (!changed)
                break;
        }
        // Group vectors by cluster - return cluster indices instead of actual vectors
        const clusterIndices = Array(k).fill(null).map(() => []);
        for (let i = 0; i < vectors.length; i++) {
            clusterIndices[assignments[i]].push(i);
        }
        return { clusters: clusterIndices, centroids, assignments };
    }
    /**
     * Find the most similar vectors to a query vector
     */
    static findSimilar(queryVector, vectors, topK = 5) {
        const similarities = vectors.map((vector, index) => ({
            index,
            similarity: this.cosineSimilarity(queryVector, vector)
        }));
        similarities.sort((a, b) => b.similarity - a.similarity);
        const topResults = similarities.slice(0, topK);
        return {
            indices: topResults.map(r => r.index),
            similarities: topResults.map(r => r.similarity)
        };
    }
    /**
     * Create a simple TF-IDF vector for text
     */
    static createTfIdfVector(text, vocabulary, documentFrequencies, totalDocuments) {
        const words = text.toLowerCase().split(/\s+/);
        const termFrequencies = new Map();
        // Calculate term frequencies
        for (const word of words) {
            termFrequencies.set(word, (termFrequencies.get(word) || 0) + 1);
        }
        // Create TF-IDF vector
        const vector = [];
        for (const term of vocabulary) {
            const tf = (termFrequencies.get(term) || 0) / words.length;
            const df = documentFrequencies.get(term) || 1;
            const idf = Math.log(totalDocuments / df);
            vector.push(tf * idf);
        }
        return this.normalizeVector(vector);
    }
    /**
     * Build vocabulary from a collection of texts
     */
    static buildVocabulary(texts, minFrequency = 2) {
        const wordCounts = new Map();
        const documentFrequencies = new Map();
        for (const text of texts) {
            const words = new Set(text.toLowerCase().split(/\s+/));
            for (const word of words) {
                if (word.length > 2) {
                    wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
                    documentFrequencies.set(word, (documentFrequencies.get(word) || 0) + 1);
                }
            }
        }
        const vocabulary = Array.from(wordCounts.entries())
            .filter(([_, count]) => count >= minFrequency)
            .map(([word, _]) => word)
            .sort();
        return { vocabulary, documentFrequencies };
    }
}
//# sourceMappingURL=VectorUtils.js.map
/**
 * File System Utilities
 * Enhanced file operations for memory management
 */
import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import { createHash } from 'crypto';
import { createReadStream, createWriteStream } from 'fs';
import { pipeline } from 'stream/promises';
import { createGzip, createGunzip } from 'zlib';
export class FileUtils {
    /**
     * Ensure directory exists, create if it doesn't
     */
    static async ensureDirectory(dirPath) {
        try {
            await fs.access(dirPath);
        }
        catch {
            await fs.mkdir(dirPath, { recursive: true });
        }
    }
    /**
     * Get file size in bytes
     */
    static async getFileSize(filePath) {
        try {
            const stats = await fs.stat(filePath);
            return stats.size;
        }
        catch {
            return 0;
        }
    }
    /**
     * Calculate file checksum (MD5)
     */
    static async calculateChecksum(filePath) {
        const hash = createHash('md5');
        const stream = createReadStream(filePath);
        for await (const chunk of stream) {
            hash.update(chunk);
        }
        return hash.digest('hex');
    }
    /**
     * Copy file with progress tracking
     */
    static async copyFile(source, destination, onProgress) {
        const sourceStats = await fs.stat(source);
        const totalSize = sourceStats.size;
        let copiedSize = 0;
        const sourceStream = createReadStream(source);
        const destStream = createWriteStream(destination);
        if (onProgress) {
            sourceStream.on('data', (chunk) => {
                copiedSize += chunk.length;
                onProgress(copiedSize / totalSize);
            });
        }
        await pipeline(sourceStream, destStream);
    }
    /**
     * Compress file using gzip
     */
    static async compressFile(inputPath, outputPath) {
        const sourceStream = createReadStream(inputPath);
        const gzipStream = createGzip();
        const destStream = createWriteStream(outputPath);
        await pipeline(sourceStream, gzipStream, destStream);
    }
    /**
     * Decompress gzip file
     */
    static async decompressFile(inputPath, outputPath) {
        const sourceStream = createReadStream(inputPath);
        const gunzipStream = createGunzip();
        const destStream = createWriteStream(outputPath);
        await pipeline(sourceStream, gunzipStream, destStream);
    }
    /**
     * Read JSON file with error handling
     */
    static async readJsonFile(filePath) {
        try {
            const content = await fs.readFile(filePath, 'utf-8');
            return JSON.parse(content);
        }
        catch {
            return null;
        }
    }
    /**
     * Write JSON file with pretty formatting
     */
    static async writeJsonFile(filePath, data, indent = 2) {
        const content = JSON.stringify(data, null, indent);
        await fs.writeFile(filePath, content, 'utf-8');
    }
    /**
     * Atomic write - write to temp file then rename
     */
    static async atomicWrite(filePath, content) {
        const tempPath = `${filePath}.tmp`;
        await fs.writeFile(tempPath, content, 'utf-8');
        await fs.rename(tempPath, filePath);
    }
    /**
     * Get directory size recursively
     */
    static async getDirectorySize(dirPath) {
        let totalSize = 0;
        async function calculateSize(currentPath) {
            const stats = await fs.stat(currentPath);
            if (stats.isFile()) {
                totalSize += stats.size;
            }
            else if (stats.isDirectory()) {
                const entries = await fs.readdir(currentPath);
                await Promise.all(entries.map(entry => calculateSize(path.join(currentPath, entry))));
            }
        }
        await calculateSize(dirPath);
        return totalSize;
    }
    /**
     * Find files matching pattern
     */
    static async findFiles(dirPath, pattern, recursive = true) {
        const results = [];
        async function search(currentPath) {
            try {
                const entries = await fs.readdir(currentPath, { withFileTypes: true });
                for (const entry of entries) {
                    const fullPath = path.join(currentPath, entry.name);
                    if (entry.isFile() && pattern.test(entry.name)) {
                        results.push(fullPath);
                    }
                    else if (entry.isDirectory() && recursive) {
                        await search(fullPath);
                    }
                }
            }
            catch {
                // Ignore errors (permission denied, etc.)
            }
        }
        await search(dirPath);
        return results;
    }
    /**
     * Clean up old files based on age
     */
    static async cleanupOldFiles(dirPath, maxAgeMs) {
        const deletedFiles = [];
        const cutoffTime = Date.now() - maxAgeMs;
        try {
            const entries = await fs.readdir(dirPath, { withFileTypes: true });
            for (const entry of entries) {
                if (entry.isFile()) {
                    const filePath = path.join(dirPath, entry.name);
                    const stats = await fs.stat(filePath);
                    if (stats.mtime.getTime() < cutoffTime) {
                        await fs.unlink(filePath);
                        deletedFiles.push(filePath);
                    }
                }
            }
        }
        catch {
            // Ignore errors
        }
        return deletedFiles;
    }
    /**
     * Create backup of file with timestamp
     */
    static async createBackup(filePath, backupDir) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const fileName = path.basename(filePath);
        const backupFileName = `${fileName}.backup.${timestamp}`;
        const backupPath = backupDir
            ? path.join(backupDir, backupFileName)
            : path.join(path.dirname(filePath), backupFileName);
        await this.ensureDirectory(path.dirname(backupPath));
        await this.copyFile(filePath, backupPath);
        return backupPath;
    }
    /**
     * Rotate log files (keep only N most recent)
     */
    static async rotateFiles(dirPath, pattern, maxFiles) {
        const files = await this.findFiles(dirPath, pattern, false);
        // Sort by modification time (newest first)
        const fileStats = await Promise.all(files.map(async (file) => ({
            path: file,
            mtime: (await fs.stat(file)).mtime
        })));
        fileStats.sort((a, b) => b.mtime.getTime() - a.mtime.getTime());
        // Delete files beyond the limit
        const filesToDelete = fileStats.slice(maxFiles);
        await Promise.all(filesToDelete.map(file => fs.unlink(file.path)));
    }
    /**
     * Watch directory for changes
     */
    static async watchDirectory(dirPath, callback) {
        const watcher = fsSync.watch(dirPath, { recursive: true });
        watcher.on('change', callback);
        return () => {
            watcher.close();
        };
    }
    /**
     * Get file metadata
     */
    static async getFileMetadata(filePath) {
        try {
            const stats = await fs.stat(filePath);
            return {
                size: stats.size,
                created: stats.birthtime,
                modified: stats.mtime,
                accessed: stats.atime,
                isFile: stats.isFile(),
                isDirectory: stats.isDirectory(),
                permissions: stats.mode.toString(8),
                checksum: stats.isFile() ? await this.calculateChecksum(filePath) : undefined
            };
        }
        catch {
            return null;
        }
    }
    /**
     * Format file size in human readable format
     */
    static formatFileSize(bytes) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let size = bytes;
        let unitIndex = 0;
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        return `${size.toFixed(unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
    }
    /**
     * Validate file path security (prevent directory traversal)
     */
    static validatePath(filePath, allowedBasePath) {
        const resolvedPath = path.resolve(filePath);
        const resolvedBasePath = path.resolve(allowedBasePath);
        return resolvedPath.startsWith(resolvedBasePath);
    }
    /**
     * Create temporary file
     */
    static async createTempFile(prefix = 'temp', suffix = '.tmp') {
        const tempDir = process.env.TMPDIR || process.env.TEMP || '/tmp';
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2);
        const tempPath = path.join(tempDir, `${prefix}_${timestamp}_${random}${suffix}`);
        // Create empty file
        await fs.writeFile(tempPath, '', 'utf-8');
        return tempPath;
    }
    /**
     * Cleanup temporary files
     */
    static async cleanupTempFiles(pattern = /temp_.*\.tmp$/) {
        const tempDir = process.env.TMPDIR || process.env.TEMP || '/tmp';
        const tempFiles = await this.findFiles(tempDir, pattern, false);
        let deletedCount = 0;
        for (const file of tempFiles) {
            try {
                await fs.unlink(file);
                deletedCount++;
            }
            catch {
                // Ignore errors
            }
        }
        return deletedCount;
    }
}
//# sourceMappingURL=FileUtils.js.map
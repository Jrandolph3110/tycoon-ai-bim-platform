/**
 * Memory Models and Interfaces
 * Core data structures for the Temporal Neural Nexus
 */
export interface MemoryMetadata {
    id: string;
    title: string;
    content: string;
    tags: string[];
    category: string;
    importance: number;
    accessCount: number;
    lastAccessed: Date;
    created: Date;
    modified: Date;
    context: string;
    location?: string;
    relationships: string[];
    embedding?: number[];
    summary?: string;
    keyInsights?: string[];
    mood?: string;
    environment?: string;
}
export interface MemorySearchResult {
    memory: MemoryMetadata;
    score: number;
    matchType: 'exact' | 'fuzzy' | 'semantic' | 'tag' | 'category';
    matchedFields: string[];
}
export interface MemoryCluster {
    id: string;
    name: string;
    description: string;
    memoryIds: string[];
    centroid?: number[];
    created: Date;
    lastUpdated: Date;
}
export interface MemoryTemplate {
    id: string;
    name: string;
    description: string;
    fields: TemplateField[];
    defaultTags: string[];
    defaultCategory: string;
}
export interface TemplateField {
    name: string;
    type: 'text' | 'number' | 'date' | 'tags' | 'category';
    required: boolean;
    placeholder?: string;
    defaultValue?: any;
}
export interface MemoryRelationship {
    fromId: string;
    toId: string;
    type: 'related' | 'follows' | 'references' | 'contradicts' | 'updates';
    strength: number;
    created: Date;
    description?: string;
}
export interface MemoryContext {
    id: string;
    name: string;
    description: string;
    isActive: boolean;
    memoryIds: string[];
    created: Date;
    lastUsed: Date;
    settings: {
        autoTag?: boolean;
        defaultCategory?: string;
        importanceThreshold?: number;
    };
}
export interface BulkMemoryOperation {
    operation: 'create' | 'update' | 'delete' | 'tag' | 'categorize';
    memories: Partial<MemoryMetadata>[];
    options?: {
        skipValidation?: boolean;
        autoTag?: boolean;
        preserveTimestamps?: boolean;
    };
}
export interface MemoryExportFormat {
    format: 'json' | 'markdown' | 'csv' | 'html';
    includeMetadata: boolean;
    includeRelationships: boolean;
    dateRange?: {
        start: Date;
        end: Date;
    };
    tags?: string[];
    categories?: string[];
}
export interface MemoryBackup {
    id: string;
    created: Date;
    description: string;
    memoryCount: number;
    size: number;
    checksum: string;
    path: string;
    compressed: boolean;
}
export type MemoryCreateInput = Omit<MemoryMetadata, 'id' | 'created' | 'modified' | 'lastAccessed' | 'accessCount'>;
export type MemoryUpdateInput = Partial<Omit<MemoryMetadata, 'id' | 'created'>>;
export type MemoryFilter = Partial<Pick<MemoryMetadata, 'tags' | 'category' | 'context' | 'importance'>>;
//# sourceMappingURL=Memory.d.ts.map
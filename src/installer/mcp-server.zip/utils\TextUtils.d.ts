/**
 * Text Processing Utilities
 * Advanced text analysis and processing functions
 */
export declare class TextUtils {
    private static readonly STOP_WORDS;
    /**
     * Extract keywords from text using TF-IDF and frequency analysis
     */
    static extractKeywords(text: string, maxKeywords?: number): string[];
    /**
     * Tokenize text into words
     */
    static tokenize(text: string): string[];
    /**
     * Calculate text similarity using Jaccard index
     */
    static jaccardSimilarity(text1: string, text2: string): number;
    /**
     * Calculate Levenshtein distance between two strings
     */
    static levenshteinDistance(str1: string, str2: string): number;
    /**
     * Calculate fuzzy string similarity (0-1 scale)
     */
    static fuzzySimilarity(str1: string, str2: string): number;
    /**
     * Extract sentences from text
     */
    static extractSentences(text: string): string[];
    /**
     * Generate a summary of text (extractive summarization)
     */
    static generateSummary(text: string, maxSentences?: number): string;
    /**
     * Extract key phrases from text
     */
    static extractKeyPhrases(text: string, maxPhrases?: number): string[];
    /**
     * Detect the language of text (simple heuristic)
     */
    static detectLanguage(text: string): string;
    /**
     * Clean and normalize text
     */
    static cleanText(text: string): string;
    /**
     * Calculate readability score (Flesch Reading Ease approximation)
     */
    static calculateReadability(text: string): {
        score: number;
        level: string;
        description: string;
    };
    /**
     * Count syllables in a word (approximation)
     */
    private static countSyllables;
    /**
     * Generate auto-tags from text content
     */
    static generateAutoTags(text: string, maxTags?: number): string[];
}
//# sourceMappingURL=TextUtils.d.ts.map
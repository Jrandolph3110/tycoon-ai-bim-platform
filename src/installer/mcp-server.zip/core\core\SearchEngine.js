/**
 * Search Engine
 * Advanced search capabilities for memory retrieval
 */
import Fuse from 'fuse.js';
import { VectorUtils } from '../utils/VectorUtils.js';
import { TextUtils } from '../utils/TextUtils.js';
export class SearchEngine {
    fuseIndex = null;
    vocabulary = [];
    documentFrequencies = new Map();
    memories = [];
    /**
     * Initialize search engine with memories
     */
    initialize(memories) {
        this.memories = memories;
        this.buildFuseIndex();
        this.buildVocabulary();
    }
    /**
     * Add memory to search index
     */
    addMemory(memory) {
        this.memories.push(memory);
        this.rebuildIndices();
    }
    /**
     * Update memory in search index
     */
    updateMemory(memory) {
        const index = this.memories.findIndex(m => m.id === memory.id);
        if (index !== -1) {
            this.memories[index] = memory;
            this.rebuildIndices();
        }
    }
    /**
     * Remove memory from search index
     */
    removeMemory(memoryId) {
        this.memories = this.memories.filter(m => m.id !== memoryId);
        this.rebuildIndices();
    }
    /**
     * Comprehensive search across all memory fields
     */
    search(query, options = {}) {
        const results = [];
        const maxResults = options.maxResults || 50;
        // Apply filters first
        let filteredMemories = this.applyFilters(this.memories, query);
        if (query.text) {
            // Text-based search
            switch (query.searchType) {
                case 'exact':
                    results.push(...this.exactSearch(query.text, filteredMemories, options));
                    break;
                case 'fuzzy':
                    results.push(...this.fuzzySearch(query.text, filteredMemories, options));
                    break;
                case 'semantic':
                    results.push(...this.semanticSearch(query.text, filteredMemories, options));
                    break;
                default:
                    // Combined search
                    results.push(...this.combinedSearch(query.text, filteredMemories, options));
            }
        }
        if (query.tags && query.tags.length > 0) {
            results.push(...this.tagSearch(query.tags, filteredMemories, options));
        }
        if (query.categories && query.categories.length > 0) {
            results.push(...this.categorySearch(query.categories, filteredMemories, options));
        }
        // If no specific search criteria, return filtered memories
        if (!query.text && (!query.tags || query.tags.length === 0) && (!query.categories || query.categories.length === 0)) {
            results.push(...filteredMemories.map(memory => ({
                memory,
                score: 1.0,
                matchType: 'exact',
                matchedFields: ['all']
            })));
        }
        // Deduplicate and sort results
        const uniqueResults = this.deduplicateResults(results);
        return uniqueResults
            .sort((a, b) => b.score - a.score)
            .slice(0, maxResults);
    }
    /**
     * Find similar memories using semantic search
     */
    findSimilar(memoryId, options = {}) {
        const memory = this.memories.find(m => m.id === memoryId);
        if (!memory || !memory.embedding) {
            return [];
        }
        const similarities = VectorUtils.findSimilar(memory.embedding, this.memories
            .filter(m => m.id !== memoryId && m.embedding)
            .map(m => m.embedding), options.maxResults || 10);
        const otherMemories = this.memories.filter(m => m.id !== memoryId && m.embedding);
        return similarities.indices.map((index, i) => ({
            memory: otherMemories[index],
            score: similarities.similarities[i],
            matchType: 'semantic',
            matchedFields: ['content', 'embedding']
        }));
    }
    /**
     * Search by tags with fuzzy matching
     */
    searchByTags(tags, options = {}) {
        return this.tagSearch(tags, this.memories, options);
    }
    /**
     * Search by categories
     */
    searchByCategories(categories, options = {}) {
        return this.categorySearch(categories, this.memories, options);
    }
    /**
     * Search within date range
     */
    searchByDateRange(start, end, options = {}) {
        const filtered = this.memories.filter(memory => {
            const created = new Date(memory.created);
            return created >= start && created <= end;
        });
        return filtered.map(memory => ({
            memory,
            score: 1.0,
            matchType: 'exact',
            matchedFields: ['created']
        }));
    }
    /**
     * Full-text search across all content
     */
    fullTextSearch(query, options = {}) {
        if (!this.fuseIndex) {
            this.buildFuseIndex();
        }
        const fuseResults = this.fuseIndex.search(query, {
            limit: options.maxResults || 50
        });
        return fuseResults.map(result => ({
            memory: result.item,
            score: 1 - (result.score || 0),
            matchType: 'fuzzy',
            matchedFields: result.matches?.map(m => m.key).filter((key) => key !== undefined) || ['content']
        }));
    }
    /**
     * Get search suggestions based on partial query
     */
    getSuggestions(partialQuery, maxSuggestions = 5) {
        const suggestions = new Set();
        // Add tag suggestions
        this.memories.forEach(memory => {
            memory.tags.forEach(tag => {
                if (tag.toLowerCase().includes(partialQuery.toLowerCase())) {
                    suggestions.add(tag);
                }
            });
        });
        // Add category suggestions
        this.memories.forEach(memory => {
            if (memory.category.toLowerCase().includes(partialQuery.toLowerCase())) {
                suggestions.add(memory.category);
            }
        });
        // Add keyword suggestions from content
        const keywords = TextUtils.extractKeywords(partialQuery, 10);
        keywords.forEach(keyword => suggestions.add(keyword));
        return Array.from(suggestions).slice(0, maxSuggestions);
    }
    /**
     * Get search statistics
     */
    getSearchStats() {
        const embeddedMemories = this.memories.filter(m => m.embedding);
        const avgDimensions = embeddedMemories.length > 0
            ? embeddedMemories.reduce((sum, m) => sum + (m.embedding?.length || 0), 0) / embeddedMemories.length
            : 0;
        return {
            totalMemories: this.memories.length,
            indexedMemories: embeddedMemories.length,
            vocabularySize: this.vocabulary.length,
            averageEmbeddingDimensions: avgDimensions
        };
    }
    // Private methods
    buildFuseIndex() {
        const options = {
            keys: [
                { name: 'title', weight: 0.3 },
                { name: 'content', weight: 0.4 },
                { name: 'tags', weight: 0.2 },
                { name: 'category', weight: 0.1 }
            ],
            threshold: 0.3,
            includeScore: true,
            includeMatches: true,
            minMatchCharLength: 2
        };
        this.fuseIndex = new Fuse(this.memories, options);
    }
    buildVocabulary() {
        const texts = this.memories.map(m => `${m.title} ${m.content}`);
        const { vocabulary, documentFrequencies } = VectorUtils.buildVocabulary(texts);
        this.vocabulary = vocabulary;
        this.documentFrequencies = documentFrequencies;
    }
    rebuildIndices() {
        this.buildFuseIndex();
        this.buildVocabulary();
    }
    applyFilters(memories, query) {
        let filtered = memories;
        // Date range filter
        if (query.dateRange) {
            filtered = filtered.filter(memory => {
                const created = new Date(memory.created);
                return created >= query.dateRange.start && created <= query.dateRange.end;
            });
        }
        // Importance filter
        if (query.importance) {
            filtered = filtered.filter(memory => {
                const importance = memory.importance;
                const min = query.importance.min ?? 0;
                const max = query.importance.max ?? 10;
                return importance >= min && importance <= max;
            });
        }
        // Context filter
        if (query.contexts && query.contexts.length > 0) {
            filtered = filtered.filter(memory => query.contexts.includes(memory.context));
        }
        return filtered;
    }
    exactSearch(query, memories, options) {
        const lowerQuery = query.toLowerCase();
        const results = [];
        for (const memory of memories) {
            const matchedFields = [];
            let score = 0;
            if (memory.title.toLowerCase().includes(lowerQuery)) {
                matchedFields.push('title');
                score += 0.4;
            }
            if (memory.content.toLowerCase().includes(lowerQuery)) {
                matchedFields.push('content');
                score += 0.3;
            }
            if (memory.tags.some(tag => tag.toLowerCase().includes(lowerQuery))) {
                matchedFields.push('tags');
                score += 0.2;
            }
            if (memory.category.toLowerCase().includes(lowerQuery)) {
                matchedFields.push('category');
                score += 0.1;
            }
            if (matchedFields.length > 0) {
                results.push({
                    memory,
                    score,
                    matchType: 'exact',
                    matchedFields
                });
            }
        }
        return results;
    }
    fuzzySearch(query, memories, options) {
        if (!this.fuseIndex) {
            this.buildFuseIndex();
        }
        const fuseResults = this.fuseIndex.search(query, {
            limit: options.maxResults || 50
        });
        return fuseResults
            .filter(result => memories.some(m => m.id === result.item.id))
            .map(result => ({
            memory: result.item,
            score: 1 - (result.score || 0),
            matchType: 'fuzzy',
            matchedFields: result.matches?.map(m => m.key).filter((key) => key !== undefined) || ['content']
        }));
    }
    semanticSearch(query, memories, options) {
        const queryEmbedding = VectorUtils.createEmbedding(query);
        const results = [];
        for (const memory of memories) {
            if (memory.embedding) {
                const similarity = VectorUtils.cosineSimilarity(queryEmbedding, memory.embedding);
                if (similarity > (options.semanticThreshold || 0.1)) {
                    results.push({
                        memory,
                        score: similarity,
                        matchType: 'semantic',
                        matchedFields: ['embedding', 'content']
                    });
                }
            }
        }
        return results.sort((a, b) => b.score - a.score);
    }
    combinedSearch(query, memories, options) {
        const exactResults = this.exactSearch(query, memories, options);
        const fuzzyResults = this.fuzzySearch(query, memories, options);
        const semanticResults = this.semanticSearch(query, memories, options);
        // Combine and weight results
        const combinedResults = new Map();
        // Exact matches get highest weight
        exactResults.forEach(result => {
            combinedResults.set(result.memory.id, {
                ...result,
                score: result.score * 1.0
            });
        });
        // Fuzzy matches get medium weight
        fuzzyResults.forEach(result => {
            const existing = combinedResults.get(result.memory.id);
            if (existing) {
                existing.score = Math.max(existing.score, result.score * 0.8);
                existing.matchedFields = [...new Set([...existing.matchedFields, ...result.matchedFields])];
            }
            else {
                combinedResults.set(result.memory.id, {
                    ...result,
                    score: result.score * 0.8
                });
            }
        });
        // Semantic matches get lower weight but boost existing matches
        semanticResults.forEach(result => {
            const existing = combinedResults.get(result.memory.id);
            if (existing) {
                existing.score = Math.max(existing.score, existing.score + (result.score * 0.3));
                existing.matchedFields = [...new Set([...existing.matchedFields, ...result.matchedFields])];
            }
            else {
                combinedResults.set(result.memory.id, {
                    ...result,
                    score: result.score * 0.6
                });
            }
        });
        return Array.from(combinedResults.values());
    }
    tagSearch(tags, memories, options) {
        const results = [];
        for (const memory of memories) {
            const matchedTags = memory.tags.filter(tag => tags.some(searchTag => tag.toLowerCase().includes(searchTag.toLowerCase()) ||
                TextUtils.fuzzySimilarity(tag.toLowerCase(), searchTag.toLowerCase()) > 0.8));
            if (matchedTags.length > 0) {
                const score = matchedTags.length / Math.max(tags.length, memory.tags.length);
                results.push({
                    memory,
                    score,
                    matchType: 'tag',
                    matchedFields: ['tags']
                });
            }
        }
        return results;
    }
    categorySearch(categories, memories, options) {
        const results = [];
        for (const memory of memories) {
            const matchedCategory = categories.find(cat => memory.category.toLowerCase().includes(cat.toLowerCase()) ||
                TextUtils.fuzzySimilarity(memory.category.toLowerCase(), cat.toLowerCase()) > 0.8);
            if (matchedCategory) {
                results.push({
                    memory,
                    score: 1.0,
                    matchType: 'category',
                    matchedFields: ['category']
                });
            }
        }
        return results;
    }
    deduplicateResults(results) {
        const uniqueResults = new Map();
        for (const result of results) {
            const existing = uniqueResults.get(result.memory.id);
            if (!existing || result.score > existing.score) {
                uniqueResults.set(result.memory.id, result);
            }
        }
        return Array.from(uniqueResults.values());
    }
}
//# sourceMappingURL=SearchEngine.js.map
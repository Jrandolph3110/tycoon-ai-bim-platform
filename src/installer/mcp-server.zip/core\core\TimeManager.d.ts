/**
 * Time Manager - Simplified TypeScript version for Tycoon
 * Handles time-related operations and temporal awareness
 */
export interface TimeInfo {
    timestamp: string;
    iso: string;
    unix: number;
    timezone: string;
    formatted: string;
    relative: string;
}
export interface TimeRange {
    start: Date;
    end: Date;
}
export declare class TimeManager {
    private preferredTimezone;
    constructor();
    /**
     * Get current date and time information
     */
    getCurrentDateTime(format?: 'detailed' | 'simple' | 'iso', timezone?: string): TimeInfo;
    /**
     * Set preferred timezone
     */
    setPreferredTimezone(timezone: string): void;
    /**
     * Calculate time elapsed since a timestamp
     */
    getTimeSince(timestamp: string | number): {
        elapsed: number;
        formatted: string;
        relative: string;
    };
    /**
     * Format date and time
     */
    private formatDateTime;
    /**
     * Get relative time description
     */
    private getRelativeTime;
    /**
     * Format duration in milliseconds
     */
    private formatDuration;
    /**
     * Create time range
     */
    createTimeRange(start: string | Date, end: string | Date): TimeRange;
    /**
     * Check if date is within range
     */
    isWithinRange(date: Date, range: TimeRange): boolean;
}
//# sourceMappingURL=TimeManager.d.ts.map
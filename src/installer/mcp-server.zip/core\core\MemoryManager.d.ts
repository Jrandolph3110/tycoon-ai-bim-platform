/**
 * Memory Manager - Simplified TypeScript version for Tycoon
 * Core memory management with advanced features
 */
export interface Memory {
    id: string;
    title: string;
    content: string;
    tags: string[];
    category: string;
    importance: number;
    accessCount: number;
    lastAccessed: Date;
    created: Date;
    modified: Date;
    context: string;
    location?: string;
    relationships: string[];
    summary?: string;
    keyInsights?: string[];
    mood?: string;
    environment?: string;
}
export interface MemoryInput {
    title: string;
    content: string;
    tags?: string[];
    category?: string;
    importance?: number;
    context?: string;
    location?: string;
    relationships?: string[];
    mood?: string;
    environment?: string;
}
export interface MemoryContext {
    id: string;
    name: string;
    description: string;
    isActive: boolean;
    memoryIds: string[];
    created: Date;
    lastUsed: Date;
    settings: {
        autoTag?: boolean;
        defaultCategory?: string;
        importanceThreshold?: number;
    };
}
export interface MemoryManagerOptions {
    basePath?: string;
    autoBackup?: boolean;
    backupInterval?: number;
    enableAnalytics?: boolean;
    enableVectorSearch?: boolean;
    maxMemories?: number;
}
export declare class MemoryManager {
    private basePath;
    private memoriesPath;
    private metadataPath;
    private backupsPath;
    private memories;
    private contexts;
    private options;
    private currentContext;
    private isInitialized;
    constructor(options?: MemoryManagerOptions);
    /**
     * Initialize the memory manager
     */
    initialize(): Promise<void>;
    /**
     * Create a new memory
     */
    createMemory(input: MemoryInput): Promise<Memory>;
    /**
     * Read a memory by ID
     */
    readMemory(id: string): Promise<Memory | null>;
    /**
     * Update a memory
     */
    updateMemory(id: string, updates: Partial<MemoryInput>): Promise<Memory | null>;
    /**
     * Delete a memory
     */
    deleteMemory(id: string): Promise<boolean>;
    /**
     * Search memories (simplified)
     */
    searchMemories(query: string): Promise<Memory[]>;
    /**
     * Get all memories
     */
    getAllMemories(): Memory[];
    /**
     * Create a new context
     */
    createContext(input: {
        name: string;
        description: string;
        isActive?: boolean;
        settings?: MemoryContext['settings'];
    }): Promise<MemoryContext>;
    private ensureDirectory;
    private saveMemory;
    private saveContext;
    private loadMemories;
    private loadContexts;
    private generateAutoTags;
    private generateSummary;
    private extractKeyPhrases;
}
//# sourceMappingURL=MemoryManager.d.ts.map
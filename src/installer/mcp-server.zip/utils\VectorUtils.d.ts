/**
 * Vector Utilities for Semantic Search
 * Simple vector operations for memory similarity
 */
export declare class VectorUtils {
    /**
     * Create a simple vector embedding from text using character frequency
     * This is a basic implementation - in production you'd use a proper embedding model
     */
    static createEmbedding(text: string, dimensions?: number): number[];
    /**
     * Calculate cosine similarity between two vectors
     */
    static cosineSimilarity(vectorA: number[], vectorB: number[]): number;
    /**
     * Normalize a vector to unit length
     */
    static normalizeVector(vector: number[]): number[];
    /**
     * Calculate Euclidean distance between two vectors
     */
    static euclideanDistance(vectorA: number[], vectorB: number[]): number;
    /**
     * Find the centroid of multiple vectors
     */
    static calculateCentroid(vectors: number[][]): number[];
    /**
     * Cluster vectors using simple k-means
     */
    static kMeansCluster(vectors: number[][], k: number, maxIterations?: number): {
        clusters: number[][];
        centroids: number[][];
        assignments: number[];
    };
    /**
     * Find the most similar vectors to a query vector
     */
    static findSimilar(queryVector: number[], vectors: number[][], topK?: number): {
        indices: number[];
        similarities: number[];
    };
    /**
     * Create a simple TF-IDF vector for text
     */
    static createTfIdfVector(text: string, vocabulary: string[], documentFrequencies: Map<string, number>, totalDocuments: number): number[];
    /**
     * Build vocabulary from a collection of texts
     */
    static buildVocabulary(texts: string[], minFrequency?: number): {
        vocabulary: string[];
        documentFrequencies: Map<string, number>;
    };
}
//# sourceMappingURL=VectorUtils.d.ts.map
/**
 * File System Utilities
 * Enhanced file operations for memory management
 */
export declare class FileUtils {
    /**
     * Ensure directory exists, create if it doesn't
     */
    static ensureDirectory(dirPath: string): Promise<void>;
    /**
     * Get file size in bytes
     */
    static getFileSize(filePath: string): Promise<number>;
    /**
     * Calculate file checksum (MD5)
     */
    static calculateChecksum(filePath: string): Promise<string>;
    /**
     * Copy file with progress tracking
     */
    static copyFile(source: string, destination: string, onProgress?: (progress: number) => void): Promise<void>;
    /**
     * Compress file using gzip
     */
    static compressFile(inputPath: string, outputPath: string): Promise<void>;
    /**
     * Decompress gzip file
     */
    static decompressFile(inputPath: string, outputPath: string): Promise<void>;
    /**
     * Read JSON file with error handling
     */
    static readJsonFile<T>(filePath: string): Promise<T | null>;
    /**
     * Write JSON file with pretty formatting
     */
    static writeJsonFile(filePath: string, data: any, indent?: number): Promise<void>;
    /**
     * Atomic write - write to temp file then rename
     */
    static atomicWrite(filePath: string, content: string): Promise<void>;
    /**
     * Get directory size recursively
     */
    static getDirectorySize(dirPath: string): Promise<number>;
    /**
     * Find files matching pattern
     */
    static findFiles(dirPath: string, pattern: RegExp, recursive?: boolean): Promise<string[]>;
    /**
     * Clean up old files based on age
     */
    static cleanupOldFiles(dirPath: string, maxAgeMs: number): Promise<string[]>;
    /**
     * Create backup of file with timestamp
     */
    static createBackup(filePath: string, backupDir?: string): Promise<string>;
    /**
     * Rotate log files (keep only N most recent)
     */
    static rotateFiles(dirPath: string, pattern: RegExp, maxFiles: number): Promise<void>;
    /**
     * Watch directory for changes
     */
    static watchDirectory(dirPath: string, callback: (event: string, filename: string) => void): Promise<() => void>;
    /**
     * Get file metadata
     */
    static getFileMetadata(filePath: string): Promise<{
        size: number;
        created: Date;
        modified: Date;
        accessed: Date;
        isFile: boolean;
        isDirectory: boolean;
        permissions: string;
        checksum?: string;
    } | null>;
    /**
     * Format file size in human readable format
     */
    static formatFileSize(bytes: number): string;
    /**
     * Validate file path security (prevent directory traversal)
     */
    static validatePath(filePath: string, allowedBasePath: string): boolean;
    /**
     * Create temporary file
     */
    static createTempFile(prefix?: string, suffix?: string): Promise<string>;
    /**
     * Cleanup temporary files
     */
    static cleanupTempFiles(pattern?: RegExp): Promise<number>;
}
//# sourceMappingURL=FileUtils.d.ts.map
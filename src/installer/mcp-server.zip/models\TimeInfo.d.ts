/**
 * Time and Date Models
 * Enhanced time awareness with memory integration
 */
export interface TimeInfo {
    timestamp: number;
    iso_string: string;
    date: string;
    time: string;
    timezone: string;
    timezone_offset: string;
    day_of_week: string;
    formatted: string;
    unix_timestamp: number;
    year: number;
    month: number;
    day: number;
    hour: number;
    minute: number;
    second: number;
    millisecond: number;
    week_of_year?: number;
    quarter?: number;
    is_weekend?: boolean;
    is_business_hours?: boolean;
}
export interface TimeRange {
    start: Date;
    end: Date;
    duration: number;
    human_readable: string;
}
export interface MemoryTimelineEntry {
    memoryId: string;
    title: string;
    timestamp: Date;
    type: 'created' | 'modified' | 'accessed' | 'tagged' | 'categorized';
    details?: string;
}
export interface MemoryTimeline {
    entries: MemoryTimelineEntry[];
    timeRange: TimeRange;
    totalEntries: number;
    groupedBy: 'hour' | 'day' | 'week' | 'month' | 'year';
}
export interface TimeBasedMemoryQuery {
    timeRange: TimeRange;
    groupBy?: 'hour' | 'day' | 'week' | 'month' | 'year';
    includeTypes?: ('created' | 'modified' | 'accessed' | 'tagged' | 'categorized')[];
    memoryFilters?: {
        tags?: string[];
        categories?: string[];
        contexts?: string[];
        importance?: {
            min?: number;
            max?: number;
        };
    };
}
export interface TemporalPattern {
    pattern: 'daily' | 'weekly' | 'monthly' | 'seasonal' | 'custom';
    description: string;
    frequency: number;
    confidence: number;
    examples: Date[];
    relatedMemories: string[];
}
export interface TimeZoneInfo {
    name: string;
    abbreviation: string;
    offset: number;
    isDST: boolean;
    dstTransition?: {
        next: Date;
        type: 'start' | 'end';
    };
}
export interface WorkingHours {
    timezone: string;
    schedule: {
        [key: string]: {
            start: string;
            end: string;
            enabled: boolean;
        };
    };
    holidays?: Date[];
    breaks?: {
        start: string;
        end: string;
        name: string;
    }[];
}
export interface TimeBasedReminder {
    id: string;
    memoryId: string;
    triggerTime: Date;
    type: 'absolute' | 'relative' | 'recurring';
    message: string;
    isActive: boolean;
    created: Date;
    lastTriggered?: Date;
    recurrence?: {
        pattern: 'daily' | 'weekly' | 'monthly' | 'yearly';
        interval: number;
        endDate?: Date;
    };
}
export interface DurationInfo {
    milliseconds: number;
    seconds: number;
    minutes: number;
    hours: number;
    days: number;
    weeks: number;
    months: number;
    years: number;
    human_readable: string;
    precise_description: string;
}
export interface TimeCalculation {
    from: Date;
    to: Date;
    duration: DurationInfo;
    business_days?: number;
    working_hours?: number;
    timezone_differences?: {
        from_tz: string;
        to_tz: string;
        offset_difference: number;
    };
}
//# sourceMappingURL=TimeInfo.d.ts.map
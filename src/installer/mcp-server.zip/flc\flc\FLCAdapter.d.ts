/**
 * FLCAdapter - Integration layer for F.L. Crane & Sons steel framing workflows
 *
 * Provides:
 * - Steel framing operation abstractions
 * - FLC parameter management
 * - Panel processing logic
 * - Renumbering engine integration
 * - Extensible storage management
 */
import { RevitBridge, RevitElement, RevitSelection } from '../revit/RevitBridge.js';
export interface FLCPanel {
    id: string;
    containerValue: string;
    mainPanel: boolean;
    elements: RevitElement[];
    boundingBox?: {
        min: {
            x: number;
            y: number;
            z: number;
        };
        max: {
            x: number;
            y: number;
            z: number;
        };
    };
    width?: number;
    height?: number;
}
export interface FLCFramingOptions {
    studSpacing: number;
    panelMaxWidth: number;
    wallType: string;
    includeOpenings: boolean;
    sequenceStuds: boolean;
    applyParameters: boolean;
}
export interface FLCRenumberOptions {
    startNumber: number;
    prefix?: string;
    includeSubassemblies: boolean;
    sequenceType: 'left-to-right' | 'bottom-to-top' | 'custom';
}
export declare class FLCAdapter {
    private revitBridge;
    private debugMode;
    constructor(revitBridge: RevitBridge);
    /**
     * Analyze selected walls for steel framing potential
     */
    analyzeWallsForFraming(selection?: RevitSelection): Promise<{
        walls: RevitElement[];
        totalLength: number;
        estimatedPanels: number;
        recommendations: string[];
    }>;
    /**
     * Create steel framing for selected walls
     */
    createSteelFraming(options: FLCFramingOptions, selection?: RevitSelection): Promise<{
        success: boolean;
        panelsCreated: number;
        elementsCreated: number;
        errors: string[];
    }>;
    /**
     * Renumber selected elements using FLC standards
     */
    renumberElements(options: FLCRenumberOptions, selection?: RevitSelection): Promise<{
        success: boolean;
        elementsProcessed: number;
        errors: string[];
    }>;
    /**
     * Get FLC panels from current selection
     */
    getFLCPanels(selection?: RevitSelection): Promise<FLCPanel[]>;
    /**
     * Validate panel ticket requirements
     */
    validatePanelTickets(selection?: RevitSelection): Promise<{
        valid: boolean;
        issues: string[];
        recommendations: string[];
    }>;
    /**
     * Helper: Get wall length from element
     */
    private getWallLength;
    /**
     * Helper: Check if wall has existing framing
     */
    private hasExistingFraming;
    /**
     * Helper: Check if wall type is compatible with steel framing
     */
    private isCompatibleWallType;
    /**
     * Enable/disable debug logging
     */
    setDebugMode(enabled: boolean): void;
    /**
     * Log debug messages
     */
    private log;
    /**
     * Log error messages
     */
    private logError;
}
//# sourceMappingURL=FLCAdapter.d.ts.map